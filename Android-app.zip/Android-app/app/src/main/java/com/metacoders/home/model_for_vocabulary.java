package com.metacoders.home;

public class model_for_vocabulary {



    String title, image, description;

    //constructor
    public model_for_vocabulary(){}

    //getter and setters

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
