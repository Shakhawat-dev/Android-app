package com.metacoders.home;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Bcs_Prep_POst_DeatilsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bcs__prep__post__deatils);
    }
}
